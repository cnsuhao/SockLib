# SockLib

A SockLib for C++11 and Lua5.1.

Includes async TCP/UDP socket, and Byte Buffer, and MD5/SHA1/RC4/CRC32/BASE64/U32OP... 

Two files SockLib.h/cpp only, you can easy copy them into your project.

Tested in MAC XCode.

In C++
==============================================================================

	extern "C" {
		#include "lua.h"
		#include "lualib.h"
		#include "lauxlib.h"
	}
	#include "SockLib.h"
	
	int main(int, char*)
	{
		lua_State* L = luaL_newstate();
		luaL_openlibs(L);
		
		// register
		socklib::SockLib::luaRegLib(L);

		while (1) {
			// poll
			socklib::SockLib::poll();
		}
		
		lua_close(L);
		
		return 0;
	}
	
	
In Lua
==============================================================================
	
	Object = {
		new = function(supper, data)
			local obj = {}
			obj.__index = obj
			setmetatable(obj, { __index = supper })
			for k, v in pairs(data) do
				obj[k] = v
			end
			return obj
		end
	}

	Peer = Object.new({
		bind = function(self, sock)
			local obj = Object.new(self, {
				_sock = sock
				sock.onEvent(socklib.EVT.RECV, function(bytes) 
					self:onRecv(bytes)
				end)
			})
			return obj
		end,
		
		onRecv = function(self, bytes)
			print("Peer:onRecv(" .. tostring(bytes) .. " bytes)")
			print(self._sock.inbuf:rs())
			self._sock.send("Hello from Server")
		end,
	})

	Server = Object:new({
		start = function(self, port)
			self._sock = socklib.tcp()
			
			self._sock:onEvent(socklib.EVT.ACCEPT, function()
				local s = self._sock:accept()
				Peer:bind(s)
			end)
			
			self._sock:listen(port)		
		end,	
	})
	
	Client = Object:new({
		connect = function(self, host, port)
			self._sock = socklib.tcp()
			
			self._sock.onEvent(socklib.EVT.CONNNECT, function(ok) 
				self:onConnect(ok)
			end)
			
			self._sock:connect(host, port)
		end,
		
		onConnect = function(self, ok)
			if ok then
				socklib.util.setTimer(1000, function()
					self._sock:send("Hello from Client")
				end)				
			end
		end,
		
		onRecv = function(self, bytes)
			print("Client:onRecv(" .. tostring(bytes) .. " bytes)")
			print(self._sock.inbuf:rs())
		end,
	})
